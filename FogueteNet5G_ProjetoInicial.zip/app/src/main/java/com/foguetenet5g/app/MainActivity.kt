package com.foguetenet5g.app

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.graphics.Typeface
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private var connected = false
    private lateinit var status: TextView
    private lateinit var connectButton: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(4, 12, 35)
        window.navigationBarColor = Color.rgb(4, 12, 35)

        val scroll = ScrollView(this)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(24, 36, 24, 32)
            setBackgroundColor(Color.rgb(5, 14, 42))
        }

        val logo = TextView(this).apply {
            text = "🚀\nF5G\nFOGUETE NET"
            textSize = 34f
            setTextColor(Color.rgb(60, 220, 255))
            typeface = Typeface.create("sans-serif-black", Typeface.BOLD)
            gravity = Gravity.CENTER
            setPadding(8, 24, 8, 28)
        }
        root.addView(logo, matchWidth())

        val info = TextView(this).apply {
            text = "SERVIDOR: NÃO CONFIGURADO     •     PING: --"
            textSize = 13f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setPadding(8, 12, 8, 18)
        }
        root.addView(info, matchWidth())

        val panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(18, 20, 18, 20)
            background = rounded(Color.rgb(14, 32, 67), 24)
        }
        root.addView(panel, matchWidth())

        val title = TextView(this).apply {
            text = "SUA CONEXÃO"
            textSize = 18f
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
        }
        panel.addView(title, matchWidth())

        val endpoint = TextView(this).apply {
            text = "Endpoint 01  •  WireGuard\nNenhum servidor configurado"
            textSize = 15f
            setTextColor(Color.LTGRAY)
            gravity = Gravity.CENTER
            setPadding(8, 24, 8, 24)
        }
        panel.addView(endpoint, matchWidth())

        connectButton = Button(this).apply {
            text = "CONECTAR"
            textSize = 16f
            setOnClickListener {
                Toast.makeText(this@MainActivity,
                    "Interface de demonstração. Configure um servidor WireGuard antes de conectar.",
                    Toast.LENGTH_LONG).show()
            }
        }
        panel.addView(connectButton, matchWidth())

        status = TextView(this).apply {
            text = "DESCONECTADO"
            textSize = 18f
            setTextColor(Color.YELLOW)
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            setPadding(8, 28, 8, 10)
        }
        root.addView(status, matchWidth())

        val note = TextView(this).apply {
            text = "Versão inicial de interface. Ainda não estabelece uma VPN.\nUse apenas servidores e configurações que você possui ou tem autorização para utilizar."
            textSize = 12f
            setTextColor(Color.LTGRAY)
            gravity = Gravity.CENTER
            setPadding(12, 24, 12, 12)
        }
        root.addView(note, matchWidth())

        scroll.addView(root)
        setContentView(scroll)
    }

    private fun matchWidth() = LinearLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT,
        ViewGroup.LayoutParams.WRAP_CONTENT
    )

    private fun rounded(color: Int, radius: Int): android.graphics.drawable.GradientDrawable =
        android.graphics.drawable.GradientDrawable().apply {
            setColor(color)
            cornerRadius = radius.toFloat()
            setStroke(2, Color.rgb(30, 120, 220))
        }
}
